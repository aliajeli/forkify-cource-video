import * as model from './model.js';
import recipeView from './views/recipeView.js';

// import icons from '../img/icons.svg'

// polyfills async/await
import 'regenerator-runtime/runtime';
// polyfills every thing else
import 'core-js/stable';

// console.log(icons);

// const recipeContainer = document.querySelector('.recipe');

// https://forkify-api.herokuapp.com/v2

///////////////////////////////////////

const controlRecipes = async function () {
  try {
    //   Get the Hash from url
    const id = window.location.hash.slice(1);
    console.log(id);
    if (!id) return;
    recipeView.renderSpinner();

    await model.loadRecipe(id);
    recipeView.render(model.state.recipe);
  } catch (error) {
    recipeView.renderError();
  }
};

// controlRecipes();

const init = function () {
  recipeView.addHandlerRender(controlRecipes);
};
init();
// window.addEventListener('load', controlRecipes);
