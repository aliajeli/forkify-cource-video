import { async } from 'regenerator-runtime';
import { API_URL } from './config.js';
import { getJSON } from './helpers.js';

export const state = {
  recipe: {},
  search: {
    query: '',
    results: [],
  },
};

export const loadRecipe = async function (id) {
  try {
    const data = await getJSON(`${API_URL}${id}`);
    const { recipe } = data.data;

    state.recipe = {
      id: recipe.id,
      title: recipe.title,
      publisher: recipe.publisher,
      sourceUrl: recipe.source_Url,
      image: recipe.image_url,
      servings: recipe.serving,
      cookingTime: recipe.cooking_time,
      ingredients: recipe.ingredients,
    };

    console.log(state.recipe);
  } catch (err) {
    console.error(`${err} ----`);
    throw err;
  }
};

export const loadSearchResults = async function (query) {
   try {
      state.search.query = query;
      const {data} = await getJSON(`${API_URL}?search=${query}`);
    //  console.log(data);

    state.search.results = data.recipe.map(rec => {
      return {
        id: recipe.id,
        title: recipe.title,
        publisher: recipe.publisher,
        image: recipe.image_url,
      };
    });
    console.log(state.search.results);
  } catch (err) {
    console.error(`${err} ----`);
    throw err;
  }
};
loadSearchResults('pizza');
